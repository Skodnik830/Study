package ru.sovcombank.fis.pf;

import org.apache.commons.io.IOUtils;

import java.io.*;
import java.util.Collections;
import java.util.Map;

/**
 * @author Semagin Evgeniy (SemaginEA)
 */
public class TestRun {

    public static void main(String[] args) throws Exception {
        FileInputStream inputStream = new FileInputStream("test.odt");
        //FileInputStream inputStream = new FileInputStream("test1.odt");
        ByteArrayOutputStream odtByteStream = new ByteArrayOutputStream();
        IOUtils.copy(inputStream, odtByteStream);

        Map<String, String> params = Collections.singletonMap("hello.world", "Hello World!!!");
        //Map<String, String> params = Collections.singletonMap("FIO", "Hello World!!!");
        byte[] odtBytes = OdfGenerator.generateOdt(odtByteStream.toByteArray(), params);
        byte[] pdfBytes = OdfGenerator.convertOdtToPdf(odtBytes);

        File pdfFile = new File("test.pdf");
        if (pdfFile.delete()) {
            System.out.println("Replace pdf file");
        }

        ByteArrayInputStream pdfIn = new ByteArrayInputStream(pdfBytes);
        FileOutputStream pdfOut = new FileOutputStream(pdfFile);
        IOUtils.copy(pdfIn, pdfOut);
        pdfOut.close();
    }
}