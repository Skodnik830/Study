import ru.sovcombank.eledocarchive.CodeGenerator;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.pdf417.PDF417Writer;
import com.google.zxing.pdf417.encoder.Compaction;
import com.google.zxing.pdf417.encoder.Dimensions;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.edit.PDPageContentStream;
import org.apache.pdfbox.pdmodel.graphics.xobject.PDPixelMap;
import org.apache.pdfbox.pdmodel.graphics.xobject.PDXObjectImage;

public class FisCodeGenerator extends CodeGenerator {
    private static Logger logger = Logger.getLogger(FisCodeGenerator.class.getName());

    public static byte[] addPdf417ForPdfStrFmt(byte[] srcDoc, String sysId, String docId, int cols, int rows, String position, int[] excludePage){
        logger.finer("addPdf417ForPdfStrFmt begin");
        byte[] var35;
        try {
            PDDocument document;
            if (srcDoc == null) {
                return null;
            }

            try {
                document = PDDocument.load(new ByteArrayInputStream(srcDoc));
                int pageCount = document.getNumberOfPages();
                String params = sysId + "|" + docId + "|" + pageCount;
                Dimensions dimensions = new Dimensions(cols, cols, rows, rows);

                for(int i = 1; i <= pageCount; ++i) {
                    Map<EncodeHintType, Object> hints = new HashMap();
                    hints.put(EncodeHintType.PDF417_DIMENSIONS, dimensions);
                    hints.put(EncodeHintType.CHARACTER_SET, "windows-1251");
                    hints.put(EncodeHintType.PDF417_COMPACTION, Compaction.BYTE);
                    BitMatrix bitMatrix = (new PDF417Writer()).encode(params + "|" + i, BarcodeFormat.PDF_417, 0, 0, hints);
                    ByteArrayOutputStream img = new ByteArrayOutputStream();
                    MatrixToImageWriter.writeToStream(bitMatrix, "PNG", img);
                    PDPage page = (PDPage)document.getDocumentCatalog().getAllPages().get(i - 1);
                    PDRectangle mediaBox = page.getMediaBox();
                    BufferedImage bim = ImageIO.read(new ByteArrayInputStream(img.toByteArray()));
                    PDXObjectImage pdImage = new PDPixelMap(document, bim);
                    PDPageContentStream contentStream = new PDPageContentStream(document, page, true, true, true);

                    try {
                        float scale = 0.5F;
                        float posX;
                        float posY;
                        if ("RT".equals(position)) {
                            posX = mediaBox.getUpperRightX() - (float)pdImage.getWidth() * scale;
                            posY = mediaBox.getUpperRightY() - (float)pdImage.getHeight() * scale;
                        } else {
                            if (!"RB".equals(position)) {
                                throw new Exception();
                            }

                            posX = mediaBox.getUpperRightX() - (float)pdImage.getWidth() * scale;
                            posY = 0.0F;
                        }

                        contentStream.drawXObject(pdImage, posX, posY, (float)pdImage.getWidth() * scale, (float)pdImage.getHeight() * scale);
                    } finally {
                        contentStream.close();
                    }
                }

                ByteArrayOutputStream destStream = new ByteArrayOutputStream();
                document.save(destStream);
                var35 = destStream.toByteArray();
            } catch (Exception var31) {
                logger.log(Level.FINER, "addPdf417ForPdfStrFmt error", var31);
                byte[] var7 = srcDoc;
                return var7;
            }
        } finally {
            logger.finer("addPdf417ForPdfStrFmt end");
        }

        return var35;
    }
}
