package ru.sovcombank.fis.pf;

import fr.opensagres.xdocreport.converter.*;
import fr.opensagres.xdocreport.core.document.DocumentKind;
import org.odftoolkit.simple.TextDocument;
import org.odftoolkit.simple.common.navigation.InvalidNavigationException;
import org.odftoolkit.simple.common.navigation.TextNavigation;
import org.odftoolkit.simple.common.navigation.TextSelection;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @author Semagin Evgeniy (SemaginEA)
 */
public class OdfGenerator {


    public static byte[] generateOdt(byte[] odtBytes, List<String> names, List<String> values) throws Exception {
        Map<String, String> fields = combineFields(names, values);
        return generateOdt(odtBytes, fields);
    }

    public static byte[] generateOdt(byte[] odtBytes, Map<String, String> fields) throws Exception {
        InputStream odtStream = new ByteArrayInputStream(odtBytes);
        TextDocument template = TextDocument.loadDocument(odtStream);
        populateFields(template, fields);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        template.save(out);
        template.close();

        return out.toByteArray();
    }

    public static byte[] convertOdtToPdf(byte[] odtBytes) throws XDocConverterException {
        Options options = Options.getFrom(DocumentKind.ODT).to(ConverterTypeTo.PDF);
        IConverter converter = ConverterRegistry.getRegistry().getConverter(options);

        InputStream odtStream = new ByteArrayInputStream(odtBytes);
        ByteArrayOutputStream pdfStream = new ByteArrayOutputStream();
        converter.convert(odtStream, pdfStream, options);

        return pdfStream.toByteArray();
    }

    private static Map<String, String> combineFields(List<String> names, List<String> values) {
        Iterator<String> i = names.iterator();
        Iterator<String> j = values.iterator();
        Map<String, String> result = new HashMap<>();
        while (i.hasNext() && j.hasNext()) {
            result.put(i.next(), j.next());
        }
        return result;
    }

    private static void populateFields(TextDocument template, Map<String, String> fields) throws InvalidNavigationException {
        for (Map.Entry<String, String> entry : fields.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();

            populateField(template, key, value);
        }
    }

    private static void populateField(TextDocument template, String field, String value) throws InvalidNavigationException {
        String tag = String.format("\\$\\{%s\\}", field);
        TextNavigation search = new TextNavigation(tag, template);
        while (search.hasNext()) {
            TextSelection item = (TextSelection) search.nextSelection();
            item.replaceWith(value);
        }
    }
}