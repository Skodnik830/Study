import java.util.Arrays;
import java.util.stream.IntStream;

public class Test_Array {
    private int[] test_arr = {7,1,6,77,32};

    public String check_elem(int el){
        if(IntStream.of(test_arr).anyMatch(x -> x == el))
            return "Содержит";
        else
            return "Не содержит";
    }

    public int[] str_to_arr(String s){
        return Arrays.stream(s.split(",")).map(String::trim).mapToInt(Integer::parseInt).toArray();
    }
}
