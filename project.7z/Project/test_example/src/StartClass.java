import java.util.Arrays;


public class StartClass {
    public static void main(String[] args) {
        Test_Array ts = new Test_Array();

        System.out.println(ts.check_elem(77));

        int[] mas = ts.str_to_arr("3,6,7,8");
        //int[] mas = {1,5,7,8};
        System.out.println(Arrays.toString(mas));
    }
}
