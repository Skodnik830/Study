package ru.sovcombank.eledocarchive;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.pdf417.PDF417Writer;
import com.google.zxing.pdf417.encoder.Compaction;
import com.google.zxing.pdf417.encoder.Dimensions;
//import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
//import java.io.FileOutputStream;
//import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.IntStream;
//import javax.imageio.ImageIO;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
//import org.apache.pdfbox.pdmodel.edit.PDPageContentStream;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
//import org.apache.pdfbox.pdmodel.graphics.xobject.PDPixelMap;
//import org.apache.pdfbox.pdmodel.graphics.xobject.PDXObjectImage;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;


public class CodeGenerator {
    private static Logger logger = Logger.getLogger(CodeGenerator.class.getName());

    public CodeGenerator() {
    }

    public static byte[] addPdf417ForPdfStrFmt(byte[] srcDoc, String sysId, String docId, int cols, int rows, String position) {
        logger.finer("addPdf417ForPdfStrFmt begin");

        PDDocument document;
        try {
            if (srcDoc != null) {
                try {
                    document = PDDocument.load(new ByteArrayInputStream(srcDoc));
                    int pageCount = document.getNumberOfPages();
                    String params = sysId + "|" + docId + "|" + pageCount;
                    Dimensions dimensions = new Dimensions(cols, cols, rows, rows);

                    for(int i = 1; i <= pageCount; ++i) {
                        Map<EncodeHintType, Object> hints = new HashMap();
                        hints.put(EncodeHintType.PDF417_DIMENSIONS, dimensions);
                        hints.put(EncodeHintType.CHARACTER_SET, "windows-1251");
                        hints.put(EncodeHintType.PDF417_COMPACTION, Compaction.BYTE);
                        BitMatrix bitMatrix = (new PDF417Writer()).encode(params + "|" + i, BarcodeFormat.PDF_417, 0, 0, hints);
                        ByteArrayOutputStream img = new ByteArrayOutputStream();
                        MatrixToImageWriter.writeToStream(bitMatrix, "PNG", img);
//                        PDPage page = (PDPage)document.getDocumentCatalog().getAllPages().get(i - 1);
                        PDPage page = (PDPage)document.getPage(i - 1);
                        PDRectangle mediaBox = page.getMediaBox();
//                        BufferedImage bim = ImageIO.read(new ByteArrayInputStream(img.toByteArray()));
//                        PDImageXObject pdImage = new PDPixelMap(document, bim);
                        PDImageXObject pdImage = PDImageXObject.createFromByteArray(document,img.toByteArray(),null);
                        PDPageContentStream contentStream = new PDPageContentStream(document, page, true, true, true);

                        try {
                            float scale = 0.5F;
                            float posX;
                            float posY;
                            if ("RT".equals(position)) {
                                posX = mediaBox.getUpperRightX() - (float)pdImage.getWidth() * scale;
                                posY = mediaBox.getUpperRightY() - (float)pdImage.getHeight() * scale;
                            } else {
                                if (!"RB".equals(position)) {
                                    throw new Exception();
                                }

                                posX = mediaBox.getUpperRightX() - (float)pdImage.getWidth() * scale;
                                posY = 0.0F;
                            }

                            contentStream.drawImage(pdImage, posX, posY, (float)pdImage.getWidth() * scale, (float)pdImage.getHeight() * scale);
                        } finally {
                            contentStream.close();
                        }
                    }

                    ByteArrayOutputStream destStream = new ByteArrayOutputStream();
                    document.save(destStream);
                    byte[] var35 = destStream.toByteArray();
                    return var35;
                } catch (Exception var31) {
                    logger.log(Level.FINER, "addPdf417ForPdfStrFmt error", var31);
                    byte[] var7 = srcDoc;
                    return var7;
                }
            }

            document = null;
        } finally {
            logger.finer("addPdf417ForPdfStrFmt end");
        }

        //return (byte[])document;
        return srcDoc;
    }

    public static byte[] addPdf417ForPdfStrFmt(byte[] srcDoc, String sysId, String docId, int cols, int rows, String position, String inPageQR) {
        logger.finer("addPdf417ForPdfStrFmt begin");
        int[] pageQR = Arrays.stream(inPageQR.split(",")).map(String::trim).mapToInt(Integer::parseInt).toArray();
        PDDocument document;
        try {
            if (srcDoc != null) {
                try {
                    document = PDDocument.load(new ByteArrayInputStream(srcDoc));
                    int pageCount = document.getNumberOfPages();
                    String params = sysId + "|" + docId + "|" + pageCount;
                    Dimensions dimensions = new Dimensions(cols, cols, rows, rows);

                    for(int i = 1; i <= pageCount; ++i) {
                      if(arr_contains_element(pageQR,i)) {
                          Map<EncodeHintType, Object> hints = new HashMap();
                          hints.put(EncodeHintType.PDF417_DIMENSIONS, dimensions);
                          hints.put(EncodeHintType.CHARACTER_SET, "windows-1251");
                          hints.put(EncodeHintType.PDF417_COMPACTION, Compaction.BYTE);
                          BitMatrix bitMatrix = (new PDF417Writer()).encode(params + "|" + i, BarcodeFormat.PDF_417, 0, 0, hints);
                          ByteArrayOutputStream img = new ByteArrayOutputStream();
                          MatrixToImageWriter.writeToStream(bitMatrix, "PNG", img);
//                          PDPage page = (PDPage) document.getDocumentCatalog().getAllPages().get(i - 1);
                          PDPage page = (PDPage)document.getPage(i - 1);
                          PDRectangle mediaBox = page.getMediaBox();
//                          BufferedImage bim = ImageIO.read(new ByteArrayInputStream(img.toByteArray()));
//                          PDImageXObject pdImage = new PDPixelMap(document, bim);
                          PDImageXObject pdImage = PDImageXObject.createFromByteArray(document,img.toByteArray(),null);
                          PDPageContentStream contentStream = new PDPageContentStream(document, page, true, true, true);

                          try {
                              float scale = 0.5F;
                              float posX;
                              float posY;
                              if ("RT".equals(position)) {
                                  posX = mediaBox.getUpperRightX() - (float) pdImage.getWidth() * scale;
                                  posY = mediaBox.getUpperRightY() - (float) pdImage.getHeight() * scale;
                              } else {
                                  if (!"RB".equals(position)) {
                                      throw new Exception();
                                  }

                                  posX = mediaBox.getUpperRightX() - (float) pdImage.getWidth() * scale;
                                  posY = 0.0F;
                              }

                              contentStream.drawImage(pdImage, posX, posY, (float) pdImage.getWidth() * scale, (float) pdImage.getHeight() * scale);
                          } finally {
                              contentStream.close();
                          }
                      }
                    }

                    ByteArrayOutputStream destStream = new ByteArrayOutputStream();
                    document.save(destStream);
                    byte[] var35 = destStream.toByteArray();
                    return var35;
                } catch (Exception var31) {
                    logger.log(Level.FINER, "addPdf417ForPdfStrFmt error", var31);
                    byte[] var7 = srcDoc;
                    return var7;
                }
            }

            document = null;
        } finally {
            logger.finer("addPdf417ForPdfStrFmt end");
        }

        //return (byte[])document;
        return srcDoc;
    }

    private static boolean arr_contains_element(int[] arr,int el){
        if(IntStream.of(arr).anyMatch(x -> x == el))
            return true;
        else
            return false;
    }

    static {
        logger.fine("CodeGenerator is loaded");
    }
}
