package ru.alex;

import padeg.lib.FioDecl;

public class Application {
    public static void main(String[] args) {
        FioDecl fioDecl = new FioDecl();
        String fio = fioDecl.getFIO("Житлов", "Павел", "Дмитриевич", 'м', 2);
        System.out.println(fio);
    }
}
