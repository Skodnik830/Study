package ru.sovcombank;

import padeg.lib.FioDecl;
public class Sclon {

    public Sclon(){
    };

    public static String sclonPadej(String lastName, String firstName, String middleName, char sex, int padej){
        FioDecl fioDecl = new FioDecl();
        String fio = fioDecl.getFIO(lastName, firstName, middleName, sex, padej);
        return fio;
    }
}
